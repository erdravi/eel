import eel
import requests
eel.init("web")

@eel.expose
def login(id,pwd):
    if(id=="ravi" and pwd=="ravi"):
        eel.dataPage()
    else:
        eel.invalid()
        
@eel.expose
def getData():
    response = requests.get("https://gyrocode.github.io/files/jquery-datatables/arrays_id.json")
    return response.json()['data']
    
@eel.expose
def getData1():
    response = requests.get("https://api.srv3r.com/table/")
    return response.json()

eel.start("index.html")

